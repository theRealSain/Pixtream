<?php
$servername = "localhost";
$username = "root"; // Change if you have a different database username
$password = ""; // Change if you have a database password
$dbname = "pixtream";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
?>