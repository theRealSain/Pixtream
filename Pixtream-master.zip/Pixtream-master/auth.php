<!DOCTYPE html>
<html lang="en">
<head>
    <title>PIXTREAM</title>
    <link rel="stylesheet" href="library-files/css/all.min.css.css">
    <link rel="stylesheet" href="library-files/css/fontawesome.min.css">
    <link rel="stylesheet" href="library-files/css/bootstrap.min.css">
    <link rel="stylesheet" href="additional-files/extra.css">
    <link rel="stylesheet" href="additional-files/me.css">
    <link rel="icon" type="image/x-icon" href="assets/LOGO_tab.svg" />
</head>
<body>

    <section class="h-100 gradient-form" style="background-color: #eee;">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-xl-10">
            <div class="card rounded-3 text-black">
            <div class="row g-0">

                <div class="col-lg-6" id="login-form">
                    <div class="card-body p-md-5 mx-md-4">
                        <div class="text-center">
                            <a href="index.html">
                                <img src="assets/text.svg" style="width: 350px;" alt="logo">
                            </a>
                        </div> <br>

                        <form action="login_process.php" method="post">
                            <h5 align="center">Sign in to your account!</h5> <br>

                            <?php
                            session_start();
                            if(isset($_SESSION['error'])): ?>
                                <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                            <?php endif; ?>

                            <div data-mdb-input-init class="form-outline mb-4">
                                <label class="form-label" for="form2Example11">Username</label>
                                <input type="text" id="form2Example11" class="form-control" name="username"
                                placeholder="Username" />                                
                            </div>

                            <div data-mdb-input-init class="form-outline mb-4">
                                <label class="form-label" for="form2Example22">Password</label>
                                <input type="password" id="form2Example22" class="form-control" name="password"
                                placeholder="Password" />
                            </div>

                            <div class="text-center pt-1 mb-5 pb-1">
                                <div class="d-grid gap-2">
                                    <button class="btn btn-custom" type="submit">Sign In</button>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-center pb-4">
                                <p class="mb-0 me-2">Don't have an account?
                                    <span class="form-toggle" onclick="toggleForms()"><a href="#">Sign up</a></span>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-lg-6" id="register-form" style="display: none;">
                    <div class="card-body p-md-5 mx-md-4">
                        <div class="text-center">
                            <a href="index.html">
                                <img src="assets/text.svg" style="width: 350px;" alt="logo">
                            </a>
                        </div> <br>

                        <form action="register_process.php" method="post">
                            <h5 align="center">Create an account here!</h5> <br>

                            <?php
                            if(isset($_SESSION['error'])): ?>
                                <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                            <?php endif; ?>

                            <div data-mdb-input-init class="form-outline mb-4">
                                <label class="form-label" for="form2Example11">Email</label>
                                <input type="email" id="form2Example11" class="form-control" name="email"
                                placeholder="Email address" />
                            </div>

                            <div data-mdb-input-init class="form-outline mb-4">
                                <label class="form-label" for="form2Example11">Full Name</label>
                                <input type="text" id="form2Example11" class="form-control" name="name"
                                placeholder="Full Name" />                                
                            </div>

                            <div data-mdb-input-init class="form-outline mb-4">
                                <label class="form-label" for="form2Example11">Username</label>
                                <input type="text" id="form2Example11" class="form-control" name="username"
                                placeholder="Username" />                                
                            </div>

                            <div data-mdb-input-init class="form-outline mb-4">
                                <label class="form-label" for="form2Example22">Password</label>
                                <input type="password" id="form2Example22" class="form-control" name="password"
                                placeholder="Password" />
                            </div>

                            <div class="text-center pt-1 mb-5 pb-1">
                                <div class="d-grid gap-2">
                                    <button class="btn btn-custom" type="submit">Sign Up</button>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-center pb-4">
                                <p class="mb-0 me-2">Already have an account?
                                    <span class="form-toggle" onclick="toggleForms()"><a href="#">Sign in</a></span>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                
                    <img class="index-logo" src="assets/LOGO_text.svg" alt="" width="300">

                    <h4 class="mb-4">Connect, Share, and Engage</h4>
                    <p class="small mb-0">
                        Join our community, Pixtream to share your moments, connect with friends, and explore the latest trends. 
                        Whether you're capturing life's milestones or discovering new content, Pixtream is the place to be. 
                        Dive into a vibrant social experience where your creativity knows no bounds.
                    </p>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>

    <script>
        function toggleForms() {
            var loginForm = document.getElementById('login-form');
            var registerForm = document.getElementById('register-form');
            if (loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
            }
        }
    </script>

</body>
</html>
